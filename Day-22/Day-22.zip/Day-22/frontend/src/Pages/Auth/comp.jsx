import React from "react";
import AdminSignin from "../../Components/Register/AdminSignup";
import Signin from "../../Components/Register/Signin";
import Signup from "../../Components/Register/Singup";
import { useLocation } from 'react-router-dom';

const YourComponent=()=> {
    const location=useLocation();
    if (location.pathname === "/login") {
      return <Signin />;
    }
    else if(location.pathname ==="/addmin")
    {
        return <AdminSignin />
    }
     else {
      return <Signup />;
    }
  }
  export default YourComponent;