import React from "react";
import { useLocation } from "react-router-dom";
import Signin from "../../Components/Register/Signin";
import Signup from "../../Components/Register/Singup";
import "./Auth.css" 
import AdminSignin from "../../Components/Register/AdminSignup";
import YourComponent from "./comp";


const Auth = () => {
  const location=useLocation();
  return (
    <div>
     
        <div class="flex items-center justify-center h-[100vh]">
          <div className="relative mr-10 hidden lg:block">
           
            
          </div>

          <div className="form md:w-[35vw] lg:w-[22vw]">

      <YourComponent />
           
          </div>
        </div>
      </div>
    
  );
};

export default Auth;

