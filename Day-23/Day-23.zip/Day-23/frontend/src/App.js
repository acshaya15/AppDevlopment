import { Routes, Route } from "react-router";
import Routers from "./Pages/Router/Routers";
import AdminSignin from "./Components/Register/AdminSignup";



function App() {
  return (
    <div className="">
      
<Routers/>


    </div>
  );
}

export default App;
